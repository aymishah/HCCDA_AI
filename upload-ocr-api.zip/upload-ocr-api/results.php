<?php
require_once 'db.php';
$stmt = $pdo->query("SELECT * FROM ocr_results ORDER BY created_at DESC LIMIT 20");
$rows = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>OCR Results</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f8f8f8; padding: 20px; }
        table { width: 100%; border-collapse: collapse; background: white; }
        th, td { border: 1px solid #ccc; padding: 10px; text-align: left; }
        th { background: #333; color: white; }
        tr:nth-child(even) { background: #f2f2f2; }
    </style>
</head>
<body>
    <h2>Recent OCR Results</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>File ID</th>
            <th>Word Count</th>
            <th>Unique Words</th>
            <th>Created</th>
            <th>View</th>
        </tr>
        <?php foreach ($rows as $row): ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= $row['file_id'] ?></td>
            <td><?= $row['word_count'] ?></td>
            <td><?= $row['unique_word_count'] ?></td>
            <td><?= $row['created_at'] ?></td>
            <td><a href="api.php?id=<?= $row['file_id'] ?>&key=K88841079688957" target="_blank">API</a></td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
