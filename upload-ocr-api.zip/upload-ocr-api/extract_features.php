<?php
function extract_text_from_file($filePath, $ext, $outputPathBase) {
    $outputTextPath = $outputPathBase . ".txt";

    if (in_array($ext, ['jpg', 'jpeg', 'png'])) {
        $command = "tesseract " . escapeshellarg($filePath) . " " . escapeshellarg($outputPathBase) . " 2>&1";
        shell_exec($command);
    } elseif ($ext === 'pdf') {
        $command = "pdftotext " . escapeshellarg($filePath) . " " . escapeshellarg($outputTextPath);
        shell_exec($command);
    } else {
        return false;
    }

    return file_exists($outputTextPath) ? $outputTextPath : false;
}

function clean_and_tokenize($text) {
    $stopwords = ["the", "and", "is", "in", "at", "of", "on", "to", "a", "an", "for", "with", "by", "as", "it", "this"];
    $text = strtolower($text);
    $text = preg_replace("/[^a-z0-9\s]/", "", $text);
    $tokens = explode(" ", $text);
    $tokens = array_filter($tokens, function($word) use ($stopwords) {
        return $word !== "" && !in_array($word, $stopwords);
    });
    return array_values($tokens);
}
?>
