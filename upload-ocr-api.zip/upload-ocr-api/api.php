<?php
require_once 'extract_features.php';

// 🔐 API Key check
$validApiKey = 'K88841079688957';

if (!isset($_GET['key']) || $_GET['key'] !== $validApiKey) {
    http_response_code(403);
    echo json_encode(["error" => "Invalid or missing API key."]);
    exit;
}

// 📄 Load and process OCR text
if (isset($_GET['id'])) {
    $fileId = basename($_GET['id']);
    $path = "outputs/" . $fileId . ".txt";

    if (file_exists($path)) {
        $text = file_get_contents($path);
        $tokens = clean_and_tokenize($text);
        $wordCount = count($tokens);
        $uniqueWords = count(array_unique($tokens));

        header('Content-Type: application/json');
        echo json_encode([
            "id" => $fileId,
            "raw_text" => $text,
            "cleaned_text" => implode(" ", $tokens),
            "word_count" => $wordCount,
            "unique_word_count" => $uniqueWords
        ]);
    } else {
        http_response_code(404);
        echo json_encode(["error" => "File not found."]);
    }
} else {
    echo json_encode(["error" => "ID not provided."]);
}
?>
