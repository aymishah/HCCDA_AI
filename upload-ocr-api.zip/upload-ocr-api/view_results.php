<?php
require_once 'db.php';

$limit = 10; // Records per page
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($page - 1) * $limit;

// Total count
$total = $pdo->query("SELECT COUNT(*) FROM ocr_results")->fetchColumn();
$totalPages = ceil($total / $limit);

// Fetch current page results
$stmt = $pdo->prepare("SELECT * FROM ocr_results ORDER BY created_at DESC LIMIT :limit OFFSET :offset");
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>OCR Results</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f8fafc;
            padding: 40px;
        }
        h2 {
            text-align: center;
            color: #1e3a8a;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 30px;
        }
        th, td {
            padding: 12px 15px;
            border: 1px solid #cbd5e1;
            text-align: left;
        }
        th {
            background-color: #1e40af;
            color: #fff;
        }
        tr:nth-child(even) {
            background-color: #e2e8f0;
        }
        a.api-link {
            color: #1e3a8a;
            text-decoration: none;
        }
        .pagination {
            text-align: center;
            margin-top: 25px;
        }
        .pagination a {
            display: inline-block;
            padding: 8px 12px;
            margin: 2px;
            background: #1e40af;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }
        .pagination a.active {
            background: #1e3a8a;
            font-weight: bold;
        }
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .download-btn {
            padding: 10px 15px;
            background-color: #059669;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
    </style>
</head>
<body>

    <div class="top-bar">
        <h2>Stored OCR Results</h2>
        <a href="download_csv.php" class="download-btn">⬇️ Download CSV</a>
    </div>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Word Count</th>
                <th>Unique Words</th>
                <th>Created</th>
                <th>API</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($results) > 0): ?>
                <?php foreach ($results as $row): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['file_id']) ?></td>
                        <td><?= $row['word_count'] ?></td>
                        <td><?= $row['unique_word_count'] ?></td>
                        <td><?= $row['created_at'] ?></td>
                        <td><a class="api-link" href="api.php?id=<?= $row['file_id'] ?>&key=K88841079688957" target="_blank">View JSON</a></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="5">No results found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="pagination">
        <?php for ($p = 1; $p <= $totalPages; $p++): ?>
            <a class="<?= $p === $page ? 'active' : '' ?>" href="?page=<?= $p ?>"><?= $p ?></a>
        <?php endfor; ?>
    </div>

</body>
</html>
