<?php
require_once 'extract_features.php';
require_once 'db.php';

if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
    $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
    $uniqueId = uniqid("img_");
    $uploadPath = "uploads/" . $uniqueId . "." . $ext;
    $outputPathBase = "outputs/" . $uniqueId;

    move_uploaded_file($_FILES['image']['tmp_name'], $uploadPath);

    $outputTextPath = extract_text_from_file($uploadPath, $ext, $outputPathBase);

    if ($outputTextPath && file_exists($outputTextPath)) {
        // Read and process text
        $rawText = file_get_contents($outputTextPath);
        $tokens = clean_and_tokenize($rawText);
        $wordCount = count($tokens);
        $uniqueCount = count(array_unique($tokens));
        $cleanText = implode(" ", $tokens);

        // ✅ Save to database
        $stmt = $pdo->prepare("INSERT INTO ocr_results (file_id, raw_text, cleaned_text, word_count, unique_word_count) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$uniqueId, $rawText, $cleanText, $wordCount, $uniqueCount]);

        // ✅ Output to user
        echo "✅ File processed. <br>";
        echo "<strong>API:</strong> <a href='api.php?id=$uniqueId&key=K88841079688957' target='_blank'>View JSON Output</a><br><br>";

        echo "<h3>Extracted Text:</h3><pre>" . htmlspecialchars($rawText) . "</pre>";
        echo "<h3>Cleaned Text:</h3><pre>" . htmlspecialchars($cleanText) . "</pre>";
        echo "<strong>Word Count:</strong> $wordCount<br>";
        echo "<strong>Unique Words:</strong> $uniqueCount<br>";
    } else {
        echo "❌ OCR failed.";
    }
} else {
    echo "❌ No image uploaded.";
}
?>
