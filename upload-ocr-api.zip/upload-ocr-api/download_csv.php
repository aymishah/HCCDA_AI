<?php
require_once 'db.php';

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="ocr_results.csv"');

$output = fopen('php://output', 'w');
fputcsv($output, ['ID', 'Raw Text', 'Cleaned Text', 'Word Count', 'Unique Word Count', 'Created At']);

$stmt = $pdo->query("SELECT * FROM ocr_results ORDER BY created_at DESC");
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    fputcsv($output, [
        $row['file_id'],
        $row['raw_text'],
        $row['cleaned_text'],
        $row['word_count'],
        $row['unique_word_count'],
        $row['created_at']
    ]);
}
fclose($output);
exit;
